const express = require('express');
const multer = require('multer');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const MAX_MB = parseInt(process.env.MAX_MB || '500', 10);
const RETENTION_MS = 24 * 60 * 60 * 1000; // 24 hours

// Email (invite) config — set these as environment variables to enable invites
const SMTP_HOST = process.env.SMTP_HOST;
const SMTP_PORT = parseInt(process.env.SMTP_PORT || '465', 10);
const SMTP_SECURE = (process.env.SMTP_SECURE || 'true') === 'true';
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const MAIL_FROM = process.env.MAIL_FROM || SMTP_USER;
const SITE_URL = process.env.SITE_URL || '';

let mailer = null;
if (SMTP_HOST && SMTP_USER && SMTP_PASS) {
  mailer = nodemailer.createTransport({
    host: SMTP_HOST, port: SMTP_PORT, secure: SMTP_SECURE,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });
}

const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const ITEMS_FILE = path.join(DATA_DIR, 'items.json');

fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(ITEMS_FILE)) fs.writeFileSync(ITEMS_FILE, '[]');

function loadItems() {
  try { return JSON.parse(fs.readFileSync(ITEMS_FILE, 'utf8')); }
  catch (e) { return []; }
}
function saveItems(items) {
  fs.writeFileSync(ITEMS_FILE, JSON.stringify(items, null, 2));
}
function newId() { return crypto.randomBytes(8).toString('hex'); }

// Drop anything older than 24h and delete its file
function prune() {
  const cutoff = Date.now() - RETENTION_MS;
  const items = loadItems();
  const kept = [];
  let changed = false;
  for (const it of items) {
    if (it.createdAt < cutoff) {
      changed = true;
      if (it.type === 'file') {
        try { fs.unlinkSync(path.join(UPLOAD_DIR, it.storedName)); } catch (e) {}
      }
    } else {
      kept.push(it);
    }
  }
  if (changed) saveItems(kept);
  return kept;
}
prune();
setInterval(prune, 60 * 60 * 1000); // hourly sweep

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, newId()),
});
const upload = multer({ storage, limits: { fileSize: MAX_MB * 1024 * 1024 } });

const app = express();
app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/items', (req, res) => res.json(prune()));

app.post('/api/text', (req, res) => {
  const content = (req.body && req.body.content) || '';
  if (!content.trim()) return res.status(400).json({ error: 'Text is empty.' });
  const items = loadItems();
  items.push({ id: newId(), type: 'text', content, createdAt: Date.now() });
  saveItems(items);
  res.json({ ok: true });
});

app.post('/api/upload', upload.array('files'), (req, res) => {
  const items = loadItems();
  (req.files || []).forEach((f) => {
    items.push({
      id: path.basename(f.filename),
      type: 'file',
      originalName: f.originalname,
      storedName: f.filename,
      size: f.size,
      mime: f.mimetype,
      createdAt: Date.now(),
    });
  });
  saveItems(items);
  res.json({ ok: true, count: (req.files || []).length });
});

// Inline view (used for image thumbnails)
app.get('/api/raw/:id', (req, res) => {
  const item = loadItems().find((i) => i.id === req.params.id);
  if (!item || item.type !== 'file') return res.status(404).send('Not found');
  res.setHeader('Content-Type', item.mime || 'application/octet-stream');
  res.sendFile(path.join(UPLOAD_DIR, item.storedName));
});

// Force download
app.get('/api/download/:id', (req, res) => {
  const item = loadItems().find((i) => i.id === req.params.id);
  if (!item) return res.status(404).send('Not found');
  if (item.type === 'file') {
    return res.download(path.join(UPLOAD_DIR, item.storedName), item.originalName);
  }
  const name = 'note-' + new Date(item.createdAt).toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.txt';
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="' + name + '"');
  res.send(item.content);
});

app.delete('/api/items/:id', (req, res) => {
  let items = loadItems();
  const item = items.find((i) => i.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Not found' });
  if (item.type === 'file') {
    try { fs.unlinkSync(path.join(UPLOAD_DIR, item.storedName)); } catch (e) {}
  }
  items = items.filter((i) => i.id !== req.params.id);
  saveItems(items);
  res.json({ ok: true });
});

// Send an invite email with a link to this site
app.post('/api/invite', async (req, res) => {
  const email = ((req.body && req.body.email) || '').trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ error: 'Invalid email address.' });
  if (!mailer) return res.status(500).json({ error: 'Email is not set up on the server yet.' });

  const proto = req.headers['x-forwarded-proto'] || req.protocol;
  const link = SITE_URL || (proto + '://' + req.headers['host']);
  try {
    await mailer.sendMail({
      from: MAIL_FROM,
      to: email,
      subject: "You've been invited to Drop",
      text: 'You have been invited to Drop, a shared space for text and files.\n\nOpen it here: ' + link + '\n\nAnything shared there is kept for 24 hours.',
      html: '<p>You have been invited to <b>Drop</b>, a shared space for text and files.</p>' +
            '<p><a href="' + link + '">' + link + '</a></p>' +
            '<p style="color:#666">Anything shared there is kept for 24 hours.</p>',
    });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Could not send: ' + (e.message || 'unknown error') });
  }
});

app.use((err, req, res, next) => {
  if (err && err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: 'File too large. Max is ' + MAX_MB + ' MB.' });
  }
  res.status(500).json({ error: 'Server error.' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('Drop running on http://0.0.0.0:' + PORT + '  (max ' + MAX_MB + ' MB, 24h retention)');
});
