const express = require('express');
const multer = require('multer');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const MAX_MB = parseInt(process.env.MAX_MB || '500', 10);
const RETENTION_MS = 24 * 60 * 60 * 1000; // 24 hours

// Email (invite) config — set these as environment variables to enable invites
const SMTP_HOST = process.env.SMTP_HOST;
const SMTP_PORT = parseInt(process.env.SMTP_PORT || '465', 10);
const SMTP_SECURE = (process.env.SMTP_SECURE || 'true') === 'true';
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const MAIL_FROM = process.env.MAIL_FROM || SMTP_USER;
const SITE_URL = process.env.SITE_URL || '';

let mailer = null;
if (SMTP_HOST && SMTP_USER && SMTP_PASS) {
  mailer = nodemailer.createTransport({
    host: SMTP_HOST, port: SMTP_PORT, secure: SMTP_SECURE,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });
}

const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const ITEMS_FILE = path.join(DATA_DIR, 'items.json');

fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(ITEMS_FILE)) fs.writeFileSync(ITEMS_FILE, '[]');

function loadItems() {
  try { return JSON.parse(fs.readFileSync(ITEMS_FILE, 'utf8')); }
  catch (e) { return []; }
}
function saveItems(items) {
  fs.writeFileSync(ITEMS_FILE, JSON.stringify(items, null, 2));
}
function newId() { return crypto.randomBytes(8).toString('hex'); }

// Drop anything older than 24h and delete its file
function prune() {
  const cutoff = Date.now() - RETENTION_MS;
  const items = loadItems();
  const kept = [];
  let changed = false;
  for (const it of items) {
    if (it.createdAt < cutoff) {
      changed = true;
      if (it.type === 'file') {
        try { fs.unlinkSync(path.join(UPLOAD_DIR, it.storedName)); } catch (e) {}
      }
    } else {
      kept.push(it);
    }
  }
  if (changed) saveItems(kept);
  return kept;
}
prune();
setInterval(prune, 60 * 60 * 1000); // hourly sweep

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, newId()),
});
const upload = multer({ storage, limits: { fileSize: MAX_MB * 1024 * 1024 } });

const app = express();
app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/items', (req, res) => res.json(prune()));

app.post('/api/text', (req, res) => {
  const content = (req.body && req.body.content) || '';
  if (!content.trim()) return res.status(400).json({ error: 'Text is empty.' });
  const items = loadItems();
  items.push({ id: newId(), type: 'text', content, createdAt: Date.now() });
  saveItems(items);
  res.json({ ok: true });
});

app.post('/api/upload', upload.array('files'), (req, res) => {
  const items = loadItems();
  (req.files || []).forEach((f) => {
    items.push({
      id: path.basename(f.filename),
      type: 'file',
      originalName: f.originalname,
      storedName: f.filename,
      size: f.size,
      mime: f.mimetype,
      createdAt: Date.now(),
    });
  });
  saveItems(items);
  res.json({ ok: true, count: (req.files || []).length });
});

// Inline view (used for image thumbnails)
app.get('/api/raw/:id', (req, res) => {
  const item = loadItems().find((i) => i.id === req.params.id);
  if (!item || item.type !== 'file') return res.status(404).send('Not found');
  res.setHeader('Content-Type', item.mime || 'application/octet-stream');
  res.sendFile(path.join(UPLOAD_DIR, item.storedName));
});

// Force download
app.get('/api/download/:id', (req, res) => {
  const item = loadItems().find((i) => i.id === req.params.id);
  if (!item) return res.status(404).send('Not found');
  if (item.type === 'file') {
    return res.download(path.join(UPLOAD_DIR, item.storedName), item.originalName);
  }
  const name = 'note-' + new Date(item.createdAt).toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.txt';
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="' + name + '"');
  res.send(item.content);
});

app.delete('/api/items/:id', (req, res) => {
  let items = loadItems();
  const item = items.find((i) => i.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Not found' });
  if (item.type === 'file') {
    try { fs.unlinkSync(path.join(UPLOAD_DIR, item.storedName)); } catch (e) {}
  }
  items = items.filter((i) => i.id !== req.params.id);
  saveItems(items);
  res.json({ ok: true });
});

// Build the invite email (pixel/retro font, no preview) — matches the approved sketch
function inviteHtml(link) {
  const F = "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
  const base = String(link).replace(/\/+$/, '');
  const logo = base + '/logo.png';
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Your invitation to Drop</title>
<style>
  body { margin:0; padding:0; background:#0a0b0d; }
  a { text-decoration:none; }
</style>
</head>
<body style="margin:0;padding:0;background:#0a0b0d;font-family:${F};">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#0a0b0d;">
 <tr><td align="center" style="padding:38px 16px;">
  <table role="presentation" width="500" cellpadding="0" cellspacing="0" style="width:500px;max-width:100%;background:#101216;border:1px solid #20242b;border-radius:16px;">
   <tr><td align="center" style="padding:42px 30px 36px;">

     <img src="${logo}" width="64" height="64" alt="Drop" style="display:block;width:64px;height:64px;border-radius:14px;">

     <div style="font-family:${F};color:#f1f2f4;font-size:28px;font-weight:700;line-height:1.25;padding:22px 4px 0;">You've been invited to use Drop.</div>

     <div style="padding:18px 0 26px;">
       <table role="presentation" cellpadding="0" cellspacing="0" align="center"><tr>
         <td width="48" height="3" style="width:48px;height:3px;background:#3a3f49;border-radius:2px;font-size:0;line-height:0;">&nbsp;</td>
       </tr></table>
     </div>

     <table role="presentation" cellpadding="0" cellspacing="0" align="center"><tr>
       <td style="background:#ffffff;border-radius:999px;">
         <a href="${link}" style="display:inline-block;font-family:${F};font-size:17px;font-weight:600;color:#0a0b0d;padding:14px 42px;">Open Drop</a>
       </td>
     </tr></table>

     <div style="padding:30px 0 0;">
       <table role="presentation" cellpadding="0" cellspacing="0" align="center"><tr>
         <td align="center" style="border:1px solid #2a2f37;border-radius:10px;padding:12px 16px;font-family:${F};color:#d3d7de;font-size:14px;line-height:1.4;">Do not upload confidential, private, or sensitive information.</td>
       </tr></table>
     </div>

     <div style="height:1px;line-height:1px;font-size:0;background:#20242b;margin:30px 0 0;">&nbsp;</div>

     <div style="font-family:${F};color:#8b909b;font-size:14px;line-height:1.6;padding:22px 0 0;">The Drop Team<br>drop@mobrauntech.com</div>

     <div style="font-family:${F};color:#5d626b;font-size:12px;line-height:1.6;padding:16px 4px 0;">By using Drop, you understand and agree that anything you upload, enter, or share may be accessible to anyone else using Drop. Drop is intended for simple sharing and personal use and does not provide privacy or security protections.</div>

   </td></tr>
  </table>
 </td></tr>
</table>
</body>
</html>`;
}

function inviteText(link) {
  return [
    "You've been invited to use Drop.",
    '',
    'Open Drop: ' + link,
    '',
    'Do not upload confidential, private, or sensitive information.',
    '',
    'The Drop Team',
    'drop@mobrauntech.com',
    '',
    'By using Drop, you understand and agree that anything you upload, enter, or share may be accessible to anyone else using Drop. Drop is intended for simple sharing and personal use and does not provide privacy or security protections.',
  ].join('\n');
}

// Send an invite email with a link to this site
app.post('/api/invite', async (req, res) => {
  const email = ((req.body && req.body.email) || '').trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ error: 'Invalid email address.' });
  if (!mailer) return res.status(500).json({ error: 'Email is not set up on the server yet.' });

  const proto = req.headers['x-forwarded-proto'] || req.protocol;
  const link = SITE_URL || (proto + '://' + req.headers['host']);
  try {
    await mailer.sendMail({
      from: MAIL_FROM,
      to: email,
      subject: 'Your invitation to Drop',
      text: inviteText(link),
      html: inviteHtml(link),
    });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Could not send: ' + (e.message || 'unknown error') });
  }
});

app.use((err, req, res, next) => {
  if (err && err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: 'File too large. Max is ' + MAX_MB + ' MB.' });
  }
  res.status(500).json({ error: 'Server error.' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('Drop running on http://0.0.0.0:' + PORT + '  (max ' + MAX_MB + ' MB, 24h retention)');
});
