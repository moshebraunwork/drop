# Drop

Chat-style, no-auth cross-device drop board. On one device you send text or add files; open the URL on any other device to see them. Tap text to copy, tap a file to download. Items auto-delete after 24 hours. No login, works on any browser.

## Run locally

```bash
npm install
npm start
```

Open http://localhost:3000

Settings via env vars:

- `PORT` — port to listen on (default `3000`)
- `MAX_MB` — max upload size in MB (default `500`)

Data lives in `./data` — text in `data/items.json`, files in `data/uploads/`.
Delete items from the UI, or wipe everything: `echo "[]" > data/items.json && rm -f data/uploads/*`

## Deploy on your Oracle VM (e.g. drop.mobrauntech.com)

1. Copy the folder up and install:

```bash
cd ~/apps/drop
npm install
```

2. Keep it running with a systemd service `~/.config/systemd/user/drop.service`:

```ini
[Unit]
Description=Drop board
After=network.target

[Service]
WorkingDirectory=/home/ubuntu/apps/drop
ExecStart=/usr/bin/node server.js
Environment=PORT=3000
Environment=MAX_MB=500
Restart=always

[Install]
WantedBy=default.target
```

```bash
systemctl --user daemon-reload
systemctl --user enable --now drop.service
loginctl enable-linger ubuntu   # keep running after logout
```

3. Nginx reverse proxy (`client_max_body_size` must cover MAX_MB):

```nginx
server {
    server_name drop.mobrauntech.com;
    client_max_body_size 500M;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $remote_addr;
    }
}
```

Then `certbot --nginx -d drop.mobrauntech.com`. (Port 3000 stays internal — no VCN/iptables rule needed since Nginx fronts it on 80/443.)

## Note

There is intentionally no security here — anyone with the URL can read, add, and delete everything. Keep it on an obscure subdomain or behind Cloudflare Access if you ever want a gate.
